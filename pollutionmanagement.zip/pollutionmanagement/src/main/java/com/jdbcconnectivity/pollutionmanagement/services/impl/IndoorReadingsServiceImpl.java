package com.jdbcconnectivity.pollutionmanagement.services.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import com.jdbcconnectivity.pollutionmanagement.controller.IndoorReadingsController;
import com.jdbcconnectivity.pollutionmanagement.dao.IndoorReadingsDAO;
import com.jdbcconnectivity.pollutionmanagement.dao.impl.IndoorReadingsDAOImpl;
import com.jdbcconnectivity.pollutionmanagement.model.IndoorReadings;
import com.jdbcconnectivity.pollutionmanagement.services.IndoorReadingsService;
import com.jdbcconnectivity.pollutionmanagement.util.DataBaseUtil;
import com.jdbcconnectivity.pollutionmanagement.util.PrintUtil;

public class IndoorReadingsServiceImpl implements IndoorReadingsService {

	private IndoorReadingsDAO indoorDAO;
	public static int readingID;
	
	public IndoorReadingsServiceImpl() {
		indoorDAO=new IndoorReadingsDAOImpl();
	}

	@Override
	public void takeReading(IndoorReadings reading) {
		 ArrayList<String> userIdList = new ArrayList<>();
			try (
			        Connection con = DataBaseUtil.establishConnection();
		            PreparedStatement ps = con.prepareStatement("select user_id from users");
		            ResultSet rs = ps.executeQuery();
			    ) {

	            while (rs.next()) {
	                userIdList.add(rs.getString("user_id"));
	            }

	        } catch (Exception e) {
	            e.printStackTrace();
	        }
			String[] userIds = userIdList.toArray(new String[0]);
			
			//check if the given user id exists in table or not
			boolean found = false;
			for (String id : userIds) {
	            if (id.equals(reading.getUserId())) {   
	                found = true;
	                break;
	         }}
		
		if(reading==null) {
			System.out.println("Reading data is empty");
		}
		else if(reading.getPm2_5value()<0) {
			System.out.println("PM 2.5 value cannot be Negative");
		}
		else if(reading.getCo2value()<0) {
			System.out.println("CO 2 value cannot be Negative");
		}
		else if(reading.getCoValue()<0) {
			System.out.println("CO value cannot be Negative");
		}
		else if(!found) {
			System.out.println("User ID doesn't exist");
		}
		else {
			 readingID=indoorDAO.save(reading);
			if(readingID>0) {
				System.out.println("Reading saved successfully");
			}
			else {
				System.out.println("Unable to save Reading");
			}
		}
		
		
	}

	@Override
	public void delete(int readingId) {
		boolean found=false;
		 String check ="SELECT 1 FROM indoor_readings WHERE reading_id = ?";
		 try (
		            Connection con = DataBaseUtil.establishConnection();
		            PreparedStatement ps = con.prepareStatement(check)
		        ) {
		            ps.setInt(1, readingId);

		            try (ResultSet rs = ps.executeQuery()) {
		                found= rs.next();   // true = exists
		            }

		        } catch (Exception e) {
		            e.printStackTrace();
		        }
			
			
			
			if(!found) {
				System.out.println("Reading ID does NOT exist");
			}
			else {
				int rows=indoorDAO.delete(readingId);
				if(rows>0) {
					System.out.println("Reading deleted successfully");
				}
				else {
					System.out.println("Unable to delete Reading");
				}
			}
		
		
	}

	@Override
	public void getReadingList() {
		// To fetch records from DAO layer
				ArrayList<IndoorReadings> readingList = indoorDAO.findAll();
				//changing reading object to string array
				ArrayList<String[]> dataList = new ArrayList<>();

				for (IndoorReadings u : readingList) {
				    dataList.add(PrintUtil.toStringArray(u));
				}
				
				
				if(readingList.size() > 0)
				{
					String[] fields=IndoorReadingsController.fields;
					PrintUtil.printData(fields, dataList);
				}
				else
				{
					System.out.println("No Reading data found");
				}
		
	}

	@Override
	public void getReadingDetails(int readingId) {
		boolean found=false;
		 String check ="SELECT 1 FROM air_readings WHERE reading_id = ?";
		 try (
		            Connection con = DataBaseUtil.establishConnection();
		            PreparedStatement ps = con.prepareStatement(check)
		        ) {
		            ps.setInt(1, readingId);

		            try (ResultSet rs = ps.executeQuery()) {
		                found= rs.next();   // true = exists
		            }

		        } catch (Exception e) {
		            e.printStackTrace();
		        }
		
		
		//validating given data
				
				if(!found) {
					System.out.println("Reading ID does NOT exist");
				}
				else {
					String[] fields=IndoorReadingsController.fields;
					Object[] obj = indoorDAO.findByReadingId(readingId);

					ArrayList<String[]> list = new ArrayList<>();

					String[] row = new String[obj.length];

					for (int i = 0; i < obj.length; i++) {
					    row[i] = String.valueOf(obj[i]);
					}

					list.add(row);
					PrintUtil.printData(fields, list);
				}
				
		
	}

	@Override
	public void getReadingsByUserId(String userId) {
		//extracting all the user ids from the database
		
		 ArrayList<String> userIdList = new ArrayList<>();
		try (
		        Connection con = DataBaseUtil.establishConnection();
	            PreparedStatement ps = con.prepareStatement("select user_id from indoor_readings");
	            ResultSet rs = ps.executeQuery();
		    ) {

        while (rs.next()) {
            userIdList.add(rs.getString("user_id"));
        }

    } catch (Exception e) {
        e.printStackTrace();
    }
		String[] userIds = userIdList.toArray(new String[0]);
		
		//check if the given user id exists in table or not
		boolean found = false;
		for (String id : userIds) {
        if (id.equals(userId)) {   
            found = true;
            break;
     }}
		
		//validating given data
				if(userId==null) {
					System.out.println("User ID cannot be null");
				}
				else if(!found) {
					System.out.println("This User may not have given any Reading or may be not Exists");
				}
				else {
					String[] fields = IndoorReadingsController.fields;
					Object[] obj = indoorDAO.findByUserId(userId);

					ArrayList<String[]> list = new ArrayList<>();

					for (Object o : obj) {              
					    Object[] dataRow = (Object[]) o; 

					    String[] row = new String[dataRow.length];

					    for (int i = 0; i < dataRow.length; i++) {  
					        row[i] = String.valueOf(dataRow[i]);
					    }

					    list.add(row);
					}

					PrintUtil.printData(fields, list);

				}
	
		
	}

}
