package com.jdbcconnectivity.pollutionmanagement.controller;

import java.util.Scanner;

import com.jdbcconnectivity.pollutionmanagement.model.IndoorReadings;
import com.jdbcconnectivity.pollutionmanagement.services.IndoorReadingsService;
import com.jdbcconnectivity.pollutionmanagement.services.impl.IndoorReadingsServiceImpl;
import com.jdbcconnectivity.pollutionmanagement.util.PrintUtil;

public class IndoorReadingsController {

public static String fields[]= {"  Reading ID  ","    User ID    ","    PM 2.5 Value    ","   CO 2 Value   ","   CO Value   ","     Locality     "};
	
	private  IndoorReadingsService readingService;
	public IndoorReadingsController()
	{
		//to initailize service
		this.readingService = new IndoorReadingsServiceImpl();
	}
	
	public static void printAll() {
		String field[]= {"    User ID    ","    PM 2.5 Value    ","   CO 2 Value   ","   CO Value   ","     Locality     "};
		
		
		//calling method to print border
		PrintUtil.printBorder(field);
		//calling method to print fields
		PrintUtil.printFields(field);
		
		PrintUtil.printBorder(field);
		//calling method to print multiple values
		PrintUtil.printMultipleValues(field,PrintUtil.datalist);
		
		PrintUtil.printBorder(field);
		
	}
	IndoorResultsController ir=new IndoorResultsController();

	
	
	public void registerUI(Scanner sc,String userId) {
	       
        
        System.out.print("Enter PM 2.5 value: ");
        int pm2_5Value = sc.nextInt();

        System.out.print("Enter CO 2 value: ");
        int co2Value = sc.nextInt();
        
        System.out.print("Enter CO value: ");
        int coValue = sc.nextInt();
        sc.nextLine();

        System.out.print("Enter your Locality: ");
        String locality = sc.nextLine();

      

        Object arr[] = { userId, pm2_5Value,co2Value, coValue, locality };
        PrintUtil.getData(arr);
        printAll();

        System.out.print("Confirm details (y | n): ");
        String choice=sc.nextLine();
        
        
        if ("y".equalsIgnoreCase(choice)) {
            readingService.takeReading(new IndoorReadings( userId, pm2_5Value, co2Value,coValue, locality));
            ir.registerUI(userId, pm2_5Value, co2Value, coValue, locality);
        }
        
        else if("n".equalsIgnoreCase(choice)) {
        	System.out.println("Reading not Saved...");
        }
        else {
        	System.out.println("Invalid choice");
        }
	
	}
}
