package com.jdbcconnectivity.pollutionmanagement.controller;


import com.jdbcconnectivity.pollutionmanagement.dao.AirResultsDAO;
import com.jdbcconnectivity.pollutionmanagement.dao.impl.AirResultsDAOImpl;
import com.jdbcconnectivity.pollutionmanagement.model.AirResults;
import com.jdbcconnectivity.pollutionmanagement.services.AirResultService;
import com.jdbcconnectivity.pollutionmanagement.services.impl.AirReadingsServiceImpl;
import com.jdbcconnectivity.pollutionmanagement.services.impl.AirResultServiceImpl;

public class AirResultsController {

	
public static String fields[]= {" Result Id "," Reading Id "," Category Name ","   User Id  ","   Status   ","       Value       ","     Area     "};
	
	private AirResultService resultService;
	public AirResultsController()
	{
		//to initailize service
		this.resultService = new AirResultServiceImpl();
	}
	

	
	public void registerUI(String userId,int pm2_5value,int pm10value,String locality) {
		

		String category="air";
		int readingId=AirReadingsServiceImpl.readingID;
		
		AirResultsDAO ar=new AirResultsDAOImpl();
		String status=null;
		
		double value=ar.calculateValue(pm2_5value, pm10value);
		
	
		if(value==pm2_5value) {
			status=ar.getStatus25(value);
		}
		else if(value==pm10value) {
			status =ar.getStatus10(value);
		}
		
		resultService.addResult(new AirResults(readingId,category,userId,value,status,locality));
	
   

	
	}
}
