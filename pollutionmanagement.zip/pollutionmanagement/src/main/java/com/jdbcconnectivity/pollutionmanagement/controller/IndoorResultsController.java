package com.jdbcconnectivity.pollutionmanagement.controller;

import com.jdbcconnectivity.pollutionmanagement.dao.IndoorResultsDAO;
import com.jdbcconnectivity.pollutionmanagement.dao.impl.IndoorResultsDAOImpl;
import com.jdbcconnectivity.pollutionmanagement.model.IndoorResults;
import com.jdbcconnectivity.pollutionmanagement.services.IndoorResultService;
import com.jdbcconnectivity.pollutionmanagement.services.impl.IndoorReadingsServiceImpl;
import com.jdbcconnectivity.pollutionmanagement.services.impl.IndoorResultServiceImpl;
import com.jdbcconnectivity.pollutionmanagement.util.PrintUtil;

public class IndoorResultsController {

	
public static String fields[]= {" Result Id "," Reading Id "," Category Name ","   User Id  ","   Value   ","          Status          ","     Area     "};
	
	private  IndoorResultService resultService;
	public IndoorResultsController()
	{
		//to initailize service
		this.resultService = new IndoorResultServiceImpl();
	}
	

	
	public void registerUI(String userId,int pm2_5value,int co2value,int coValue,String area) {
		
		IndoorReadingsController a =new IndoorReadingsController();
		

		String category="Indoor";
		int readingId=IndoorReadingsServiceImpl.readingID;
		
		IndoorResultsDAO ar=new IndoorResultsDAOImpl();
		String status=null;
		
		double value=ar.calculateValue(pm2_5value, co2value, coValue);
		
	
		status=ar.getStatus(value);
		
		resultService.addResult(new IndoorResults(readingId,category,userId,value,status,area));
	
   

	
	}

}
