package com.jdbcconnectivity.pollutionmanagement.services.impl;

import java.sql.*;
import java.util.ArrayList;

import com.jdbcconnectivity.pollutionmanagement.controller.UserController;
import com.jdbcconnectivity.pollutionmanagement.dao.UsersDAO;
import com.jdbcconnectivity.pollutionmanagement.dao.impl.UsersDAOImpl;
import com.jdbcconnectivity.pollutionmanagement.model.Users;
import com.jdbcconnectivity.pollutionmanagement.services.UsersService;
import com.jdbcconnectivity.pollutionmanagement.util.DataBaseUtil;
import com.jdbcconnectivity.pollutionmanagement.util.PrintUtil;

import at.favre.lib.crypto.bcrypt.BCrypt;

public class UsersServiceImpl implements UsersService{

private UsersDAO userDAO;
	
	//constructor 

	public UsersServiceImpl() {
		//to intialize DAO reference
		userDAO = new UsersDAOImpl();
	}
	
	@Override
	public void registerUser(Users user) {
		
		
		if(user == null) //verifying user object null
		{
			System.out.println("User data is empty");
		}
		else if (user.getRole() == null || (!"admin".equals(user.getRole()) && !"user".equals(user.getRole()))) {
		    System.out.println("Invalid Role");
		}
		else if(user.getPassword().length()>12) {
			System.out.println("Password Cannot be more than 12 characters in length");
		}
		
		else
		{
			//calling save method()of dao to insert the user data into the table
			int rows = userDAO.save(user);
			if(rows > 0) // number of rows greater than 0 indicates successful insert operation
			{
				System.out.println("User Successfully Registered");
			}
			else
			{
				System.out.println("Unable to register the User");
			}
		}
		
		
	}

	@Override
	public void updateArea(String userId,String  area) {
		//extracting all the user ids from the database
		 ArrayList<String> userIdList = new ArrayList<>();
		try (
		        Connection con = DataBaseUtil.establishConnection();
	            PreparedStatement ps = con.prepareStatement("select user_id from users");
	            ResultSet rs = ps.executeQuery();
		    ) {

            while (rs.next()) {
                userIdList.add(rs.getString("user_id"));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
		String[] userIds = userIdList.toArray(new String[0]);
		
		//check if the given user id exists in table or not
		boolean found = false;
		for (String id : userIds) {
            if (id.equals(userId)) {   
                found = true;
                break;
         }}
		 
		 
		
		
		//validating given data
		if(userId==null) {
			System.out.println("User ID cannot be null");
		}
		else if(area==null) {
			System.out.println("Area cannot be null");
		}
		else if(!found) {
			System.out.println("User ID does NOT exist");
		}
		else {
			int rows = userDAO.updateAreaByUserId(userId, area);
			if(rows > 0) // number of rows greater than 0 indicates successful insert operation
			{
				System.out.println("Area Sucessfully changed");
			}
			else
			{
				System.out.println("Unable to change the Area");
			}
		}
		  
		
	}

	@Override
	public void getUserList() {
		// To fetch records from DAO layer
				ArrayList<Users> userList = userDAO.findAll();
				//changing user object to string array
				ArrayList<String[]> dataList = new ArrayList<>();

				for (Users u : userList) {
				    dataList.add(PrintUtil.toStringArray(u));
				}
				
				
				if(userList.size() > 0)
				{
					String[] fields=UserController.fields;
					PrintUtil.printData(fields, dataList);
				}
				else
				{
					System.out.println("No User data found");
				}
		
	}

	@Override
	public void getUserDetails(String userId) {
		//extracting all the user ids from the database
		
		 ArrayList<String> userIdList = new ArrayList<>();
		try (
		        Connection con = DataBaseUtil.establishConnection();
	            PreparedStatement ps = con.prepareStatement("select user_id from users");
	            ResultSet rs = ps.executeQuery();
		    ) {

           while (rs.next()) {
               userIdList.add(rs.getString("user_id"));
           }

       } catch (Exception e) {
           e.printStackTrace();
       }
		String[] userIds = userIdList.toArray(new String[0]);
		
		//check if the given user id exists in table or not
		boolean found = false;
		for (String id : userIds) {
           if (id.equals(userId)) {   
               found = true;
               break;
        }}
		
		
		
		//validating given data
		if(userId==null) {
			System.out.println("User ID cannot be null");
		}
		else if(!found) {
			System.out.println("User ID does NOT exist");
		}
		else {
			String[] fields=UserController.fields;
			Object[] obj = userDAO.findByUserId(userId);

			ArrayList<String[]> list = new ArrayList<>();

			String[] row = new String[obj.length];

			for (int i = 0; i < obj.length; i++) {
			    row[i] = String.valueOf(obj[i]);
			}

			list.add(row);
			PrintUtil.printData(fields, list);
		}
		
		
		
		
	}

	@Override
	public void deleteUser(String userId) {
		 ArrayList<String> userIdList = new ArrayList<>();
			try (
			        Connection con = DataBaseUtil.establishConnection();
		            PreparedStatement ps = con.prepareStatement("select user_id from users");
		            ResultSet rs = ps.executeQuery();
			    ) {

	           while (rs.next()) {
	               userIdList.add(rs.getString("user_id"));
	           }

	       } catch (Exception e) {
	           e.printStackTrace();
	       }
			String[] userIds = userIdList.toArray(new String[0]);
			
			//check if the given user id exists in table or not
			boolean found = false;
			for (String id : userIds) {
	           if (id.equals(userId)) {   
	               found = true;
	               break;
	        }}
			
			
			if(userId==null) {
				System.out.println("User ID cannot be null");
			}
			else if(!found) {
				System.out.println("User ID does NOT exist");
			}
			else {
				int rows=userDAO.delete(userId);
				if(rows>0) {
					System.out.println("User deleted successfully");
				}
				else {
					System.out.println("Unable to delete User");
				}
			}
			
			
		
	}

	@Override
	public void updatePassword(String userId, String password) {
		//extracting all the user ids from the database
		 ArrayList<String> userIdList = new ArrayList<>();
		try (
		        Connection con = DataBaseUtil.establishConnection();
	            PreparedStatement ps = con.prepareStatement("select user_id from users");
	            ResultSet rs = ps.executeQuery();
		    ) {

           while (rs.next()) {
               userIdList.add(rs.getString("user_id"));
           }

       } catch (Exception e) {
           e.printStackTrace();
       }
		String[] userIds = userIdList.toArray(new String[0]);
		
		//check if the given user id exists in table or not
		boolean found = false;
		for (String id : userIds) {
           if (id.equals(userId)) {   
               found = true;
               break;
        }}
		 
		 
		
		
		//validating given data
		if(userId==null) {
			System.out.println("User ID cannot be null");
		}
		else if(password==null) {
			System.out.println("Password cannot be null");
		}
		else if(!found) {
			System.out.println("User ID does NOT exist");
		}
		else {
			int rows = userDAO.updatePasswordByUserId(userId, password);
			if(rows > 0) // number of rows greater than 0 indicates successful insert operation
			{
				System.out.println("Password Sucessfully changed");
			}
			else
			{
				System.out.println("Unable to change the Password");
			}
		}
		
	}

	@Override
	public void updateOldPassword(String userId, String oldPass, String newPass) {
		

	    String selectSql = "SELECT password_hash FROM users WHERE user_id = ?";

	    try (
	        Connection con = DataBaseUtil.establishConnection();
	        PreparedStatement selectStmt = con.prepareStatement(selectSql)
	    ) {
	        selectStmt.setString(1, userId);

	        try (ResultSet rs = selectStmt.executeQuery()) {

	            if (!rs.next()) {
	            	System.out.print("User not Found");
	                return;
	            }

	            String storedHash = rs.getString("password_hash");

	            boolean matched = BCrypt.verifyer()
	                    .verify(oldPass.toCharArray(), storedHash)
	                    .verified;

	            if (!matched) {
	            	System.out.print("Wrong Old Password");
	            	return;
	                // wrong old password
	            }
	        }
	        }catch(SQLException e) {
	        	e.printStackTrace();
	        }
	  
			if( oldPass == null) {
				System.out.print("Old Password cannot be null");
			}
			else if(newPass==null) {
				System.out.print("New Password cannot be null");
			}
			else if (oldPass.equals(newPass)) {
	        System.out.print("New password must be different");
	    }
			else {
				int rows=userDAO.updatePasswordByUserId(userId, newPass);
				if(rows>0) {
					System.out.print("Password changed successfully");
				}
				else {
					System.out.print("Unable to change Password");
				}
			}
	    }
	}
