package com.jdbcconnectivity.pollutionmanagement.services.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import com.jdbcconnectivity.pollutionmanagement.controller.AirReadingsController;
import com.jdbcconnectivity.pollutionmanagement.controller.AirResultsController;
import com.jdbcconnectivity.pollutionmanagement.controller.IndoorResultsController;
import com.jdbcconnectivity.pollutionmanagement.dao.IndoorResultsDAO;
import com.jdbcconnectivity.pollutionmanagement.dao.impl.IndoorResultsDAOImpl;
import com.jdbcconnectivity.pollutionmanagement.model.IndoorResults;
import com.jdbcconnectivity.pollutionmanagement.services.IndoorResultService;
import com.jdbcconnectivity.pollutionmanagement.util.DataBaseUtil;
import com.jdbcconnectivity.pollutionmanagement.util.PrintUtil;

public class IndoorResultServiceImpl implements IndoorResultService{
	
	private IndoorResultsDAO indoorDAO;
	public static int resultID;
	public IndoorResultServiceImpl() {
		indoorDAO = new IndoorResultsDAOImpl();
	}

	@Override
	public void addResult(IndoorResults result) {
		if(result==null) {
			System.out.println("Result data is empty");
		}
		else {
			 resultID=indoorDAO.save(result);
			if(resultID>0) {
				System.out.println("Result saved successfully");
			}
			else {
				System.out.println("Unable to save Result");
			}
		}
		
	}

	@Override
	public void delete(int resultId) {
		boolean found=false;
		 String check ="SELECT 1 FROM indoor_results WHERE result_id = ?";
		 try (
		            Connection con = DataBaseUtil.establishConnection();
		            PreparedStatement ps = con.prepareStatement(check)
		        ) {
		            ps.setInt(1, resultId);

		            try (ResultSet rs = ps.executeQuery()) {
		                found= rs.next();   // true = exists
		            }

		        } catch (Exception e) {
		            e.printStackTrace();
		        }
		
		
		
		if(!found) {
			System.out.println("Result ID does NOT exist");
		}
		else {
			int rows=indoorDAO.delete(resultId);
			if(rows>0) {
				System.out.println("Result deleted successfully");
			}
			else {
				System.out.println("Unable to delete Result");
			}
		}
		
	}

	@Override
	public void getResult() {
		// To fetch records from DAO layer
				ArrayList<IndoorResults> resultList = indoorDAO.findAll();
				//changing reading object to string array
				ArrayList<String[]> dataList = new ArrayList<>();

				for (IndoorResults u : resultList) {
				    dataList.add(PrintUtil.toStringArray(u));
				}
				
				
				if(resultList.size() > 0)
				{
					String[] fields=IndoorResultsController.fields;
					PrintUtil.printData(fields, dataList);
				}
				else
				{
					System.out.println("No Result data found");
				}
		
	}

	@Override
	public void getResultByResultId(int resultId) {
		boolean found=false;
		 String check ="SELECT 1 FROM indoor_results WHERE result_id = ?";
		 try (
		            Connection con = DataBaseUtil.establishConnection();
		            PreparedStatement ps = con.prepareStatement(check)
		        ) {
		            ps.setInt(1, resultId);

		            try (ResultSet rs = ps.executeQuery()) {
		                found= rs.next();   // true = exists
		            }

		        } catch (Exception e) {
		            e.printStackTrace();
		        }
		
		
		//validating given data
				
				if(!found) {
					System.out.println("Result ID does NOT exist");
				}
				else {
					String[] fields=IndoorResultsController.fields;
					Object[] obj = indoorDAO.findByResultId(resultId);

					ArrayList<String[]> list = new ArrayList<>();

					String[] row = new String[obj.length];

					for (int i = 0; i < obj.length; i++) {
					    row[i] = String.valueOf(obj[i]);
					}

					list.add(row);
					PrintUtil.printData(fields, list);
				}
				
		
	}




	@Override
	public void getResultByCategoryNameAndArea(String categoryName, String area) {
		if(categoryName==null) {
			System.out.println("Category name cannot be null");
		}
		else if(area==null) {
			System.out.println("Area cannot be null");
		}
		else {
		String[] fields=IndoorResultsController.fields;
		Object[] obj = indoorDAO.findByCategoryNameAndArea(categoryName, area);
		if(obj==null) {
			System.out.println("No Matching Data Found");
			return;
		}
		
			ArrayList<String[]> list = new ArrayList<>();

			for (Object o : obj) {              
			    Object[] dataRow = (Object[]) o; 

			    String[] row = new String[dataRow.length];

			    for (int i = 0; i < dataRow.length; i++) {  
			        row[i] = String.valueOf(dataRow[i]);
			    }

			    list.add(row);
			}

			PrintUtil.printData(fields, list);
			}
		
	}

	@Override
	public void getResultByUserId(String userId) {
		if(userId==null) {
			System.out.println("User ID cannot be null");
		}
		else {
			String[] fields = IndoorResultsController.fields;
			Object[] obj = indoorDAO.findByUserId(userId);
			if(obj==null) {
				System.out.println("No Matching Data Found");
				return;
				
			}
			
			ArrayList<String[]> list = new ArrayList<>();

			for (Object o : obj) {              
			    Object[] dataRow = (Object[]) o; 

			    String[] row = new String[dataRow.length];

			    for (int i = 0; i < dataRow.length; i++) {  
			        row[i] = String.valueOf(dataRow[i]);
			    }

			    list.add(row);
			}

			PrintUtil.printData(fields, list);

		}
		
	}
		



}
