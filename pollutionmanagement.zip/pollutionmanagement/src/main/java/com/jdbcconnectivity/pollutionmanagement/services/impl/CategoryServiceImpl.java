package com.jdbcconnectivity.pollutionmanagement.services.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import com.jdbcconnectivity.pollutionmanagement.controller.CategoryController;
import com.jdbcconnectivity.pollutionmanagement.dao.CategoryDAO;
import com.jdbcconnectivity.pollutionmanagement.dao.impl.CategoryDAOImpl;
import com.jdbcconnectivity.pollutionmanagement.model.Category;
import com.jdbcconnectivity.pollutionmanagement.services.CategoryService;
import com.jdbcconnectivity.pollutionmanagement.util.ConsoleUtil;
import com.jdbcconnectivity.pollutionmanagement.util.DataBaseUtil;
import com.jdbcconnectivity.pollutionmanagement.util.PrintUtil;

public class CategoryServiceImpl implements CategoryService{

	private CategoryDAO catDAO;
	public static int categoryID;
	public CategoryServiceImpl() {
		catDAO = new CategoryDAOImpl();
	}
	
	@Override
	public void registerCategory(Category category) {
		
		
		if(category==null) {
			System.out.println("Category data is empty");
			
		}
		
		else {
			 categoryID=catDAO.save(category);
			if(categoryID>0) {
				System.out.println("Category saved successfully");
				
			}
			else {
				System.out.println("Unable to save Category");
				
			}
		}
		
	}

	@Override
	public void delete(int categoryId) {
		boolean found=false;
		 String check ="SELECT 1 FROM category WHERE category_id = ?";
		 try (
		            Connection con = DataBaseUtil.establishConnection();
		            PreparedStatement ps = con.prepareStatement(check)
		        ) {
		            ps.setInt(1, categoryId);

		            try (ResultSet rs = ps.executeQuery()) {
		                found= rs.next();   // true = exists
		            }

		        } catch (Exception e) {
		            e.printStackTrace();
		        }
		
		
		if(!found) {
			System.out.println("Category ID does NOT exist");
		}
		else {
			int rows=catDAO.delete(categoryId);
			if(rows>0) {
				System.out.println("Category deleted successfully");
			}
			else {
				System.out.println("Unable to delete Category");
			}
		}
	
		
	}

	@Override
	public void getCategoryList() {
		// To fetch records from DAO layer
				ArrayList<Category> categoryList = catDAO.findAll();
				//changing reading object to string array
				ArrayList<String[]> dataList = new ArrayList<>();

				for (Category u : categoryList) {
				    dataList.add(PrintUtil.toStringArray(u));
				}
				
				
				if(categoryList.size() > 0)
				{
					String[] fields=CategoryController.fields;
					PrintUtil.printData(fields, dataList);
				}
				else
				{
					System.out.println("No Category data found");
					System.out.println(categoryList);
				}
		
	}

	@Override
	public void getCategoryDetails(int categoryId) {
		
		ArrayList<String> categoryList = new ArrayList<>();
		try (
		        Connection con = DataBaseUtil.establishConnection();
	            PreparedStatement ps = con.prepareStatement("select category_id from category");
	            ResultSet rs = ps.executeQuery();
		    ) {

           while (rs.next()) {
               categoryList.add(rs.getString("category_id"));
           }

       } catch (Exception e) {
           e.printStackTrace();
       }
		String[] categoryIds = categoryList.toArray(new String[0]);
		
		//check if the given Category id exists in table or not
		boolean found = false;
		for (String id : categoryIds) {
           if (id.equals(categoryId)) {   
               found = true;
               break;
        }}
		
		//validating given data
		
		if(!found) {
			System.out.println("Category ID does NOT exist");
		}
		else {
			String[] fields=CategoryController.fields;
			Object[] obj = catDAO.findByCategoryId(categoryId);

			ArrayList<String[]> list = new ArrayList<>();

			String[] row = new String[obj.length];

			for (int i = 0; i < obj.length; i++) {
			    row[i] = String.valueOf(obj[i]);
			}

			list.add(row);
			PrintUtil.printData(fields, list);
		}
		
	}

	

}
