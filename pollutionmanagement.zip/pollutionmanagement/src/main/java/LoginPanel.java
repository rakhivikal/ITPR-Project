import java.util.*;

public class LoginPanel {
	  public static final String RESET = "\033[0m";
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		  Scanner sc = new Scanner(System.in);
		  System.out.println("\033[42m\033[30m" + "Login as:" + RESET);
		  System.out.println("1. Admin");
	        System.out.println("2. User");
	        System.out.print("Enter your choice: ");
	       

	        int choice = sc.nextInt();

	        switch (choice) {
	            case 1:
	            	System.out.println("Welcome to Admin Panel");
	                break;
	            case 2:
	            	System.out.println("Welcome to Users Panel");
	                break;
	            default:
	                System.out.println("Invalid choice! Try again.");
	}

}
}
